(function () {
  function resolveReportHref(fileName) {
    const path = String(window.location.pathname || "").replace(/\\/g, "/").toLowerCase();
    const inReportHtmlDir = path.indexOf("/report_html/") !== -1 || /\/report_html\/?$/.test(path);
    if (inReportHtmlDir) return fileName;
    if (window.location.protocol === "file:") return "report_html/" + fileName;
    return fileName;
  }

  const REPORTS = [
    { title: "Dashboard", href: resolveReportHref("dashboard.html"), icon: "H", file: "dashboard.html" },
    { title: "Nested View Report", href: resolveReportHref("nested_view_report.html"), icon: "N", file: "nested_view_report.html" },
    { title: "Missed Entries Report", href: resolveReportHref("missed_entries.html"), icon: "M", file: "missed_entries.html" },
    { title: "Assignee Hours Report", href: resolveReportHref("assignee_hours_report.html"), icon: "A", file: "assignee_hours_report.html" },
    { title: "Employee Performance", href: resolveReportHref("employee_performance_report.html"), icon: "E", file: "employee_performance_report.html" },
    { title: "RLT Leave Report", href: resolveReportHref("rlt_leave_report.html"), icon: "R", file: "rlt_leave_report.html" },
    { title: "Leaves Planned Calendar", href: resolveReportHref("leaves_planned_calendar.html"), icon: "L", file: "leaves_planned_calendar.html" },
    { title: "RnD Data Story", href: resolveReportHref("rnd_data_story.html"), icon: "D", file: "rnd_data_story.html" },
    { title: "gantt chart", href: resolveReportHref("gantt_chart_report.html"), icon: "G", file: "gantt_chart_report.html" },
    { title: "Phase RMI Gantt", href: resolveReportHref("phase_rmi_gantt_report.html"), icon: "P", file: "phase_rmi_gantt_report.html" },
    { title: "IPP Meeting Dashboard", href: resolveReportHref("ipp_meeting_dashboard.html"), icon: "I", file: "ipp_meeting_dashboard.html" }
  ];

  const storageKey = "unified-report-nav-collapsed";
  const isMobile = window.matchMedia("(max-width: 959px)").matches;
  const currentFile = (window.location.pathname.split("/").pop() || "").toLowerCase();

  const nav = document.createElement("aside");
  nav.className = "unified-nav";
  nav.setAttribute("aria-label", "Reports navigation");

  const savedCollapsed = localStorage.getItem(storageKey) === "1";
  if (!isMobile && savedCollapsed) {
    nav.classList.add("is-collapsed");
    document.body.classList.add("unified-nav-collapsed");
  }

  const head = document.createElement("div");
  head.className = "unified-nav-head";

  const brand = document.createElement("div");
  brand.innerHTML = '<h2 class="unified-nav-title">Reports</h2><div class="unified-nav-sub">Unified Navigation</div>';

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.className = "unified-nav-toggle";
  toggle.textContent = "\u2261";
  toggle.setAttribute("aria-label", "Toggle navigation");

  head.appendChild(brand);
  head.appendChild(toggle);
  nav.appendChild(head);

  const list = document.createElement("nav");
  list.className = "unified-nav-list";

  REPORTS.forEach((item) => {
    const link = document.createElement("a");
    link.className = "unified-nav-link";
    link.href = item.href;
    if (currentFile === item.file.toLowerCase()) {
      link.classList.add("is-active");
      link.setAttribute("aria-current", "page");
    }

    const icon = document.createElement("span");
    icon.className = "unified-nav-icon";
    icon.textContent = item.icon;

    const label = document.createElement("span");
    label.className = "unified-nav-label";
    label.textContent = item.title;

    link.appendChild(icon);
    link.appendChild(label);
    list.appendChild(link);
  });

  nav.appendChild(list);

  const mobileBtn = document.createElement("button");
  mobileBtn.type = "button";
  mobileBtn.className = "unified-nav-mobile-btn";
  mobileBtn.textContent = "\u2630";
  mobileBtn.setAttribute("aria-label", "Open reports navigation");

  const scrim = document.createElement("div");
  scrim.className = "unified-nav-scrim";

  const closeMobile = function () {
    nav.classList.remove("is-open");
    scrim.classList.remove("is-open");
  };

  toggle.addEventListener("click", function () {
    if (isMobile) {
      closeMobile();
      return;
    }
    const collapsed = nav.classList.toggle("is-collapsed");
    document.body.classList.toggle("unified-nav-collapsed", collapsed);
    localStorage.setItem(storageKey, collapsed ? "1" : "0");
  });

  mobileBtn.addEventListener("click", function () {
    nav.classList.add("is-open");
    scrim.classList.add("is-open");
  });

  scrim.addEventListener("click", closeMobile);

  document.body.classList.add("unified-nav-enabled");
  document.body.appendChild(nav);
  document.body.appendChild(scrim);
  document.body.appendChild(mobileBtn);
})();
